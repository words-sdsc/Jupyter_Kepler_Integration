ipython-kepler-iontegration
===========================

This repo contains the pythone app and then kepler actor than will be integrated with ipython notebook
